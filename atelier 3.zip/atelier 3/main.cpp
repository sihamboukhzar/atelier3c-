#include <iostream>
#include<math.h>
//programme 1
/*class Myclass{  //d�finition  d'une classe appel�e MyClass
  public:
    Myclass();//un constructeur
   ~Myclass();//un destructeur
  };

    Myclass::Myclass(void){ //D�finition  le constructeur en dehors de la classe.
    cout<<"Entrez votre prenom :";
    string prenom;
    cin>>prenom;
    cout<<"Bonjour "<<prenom<<"\n";
    return ;
};
    Myclass::~Myclass(){ //D�finition  le destructeur en dehors de la classe.
              cout<<"Entrez votre nom :";
               string nom;
               cin>>nom;
              cout<<"Bonjour "<<nom<<"\n";
            return;
};
int main(){
 Myclass e1;//creation d'un objet
   return 0;
}
*/

/*
//programme3
#include <iostream>
#include<math.h>
using namespace std;
class Complex { //classe complexe
public:
double r; //declaration des variable
double i;//declaration des variable
public:
Complex();//un constructeur par d�faut
void add(Complex, Complex); //methode l'operation d'addition
void subtract(Complex, Complex); //methode l'operation de soustraction
void div(Complex, Complex); //methode l'operation de dividion
void prod(Complex, Complex); //methode l'operation de production
void print(); //methode d'affichage
};
Complex::Complex() { //definition de constructeur en dehors de classe
r = i = 0; //l'initiation
}
void Complex::add (Complex op1, Complex op2) { //definition de methode d'addition
r = op1.r+op2.r;
i = op1.i+op2.i;
}
void Complex::subtract (Complex op1, Complex op2) { //definition  de methode de soustraction
r = op1.r-op2.r;
i = op1.i-op2.i;
}
void Complex::div (Complex op1, Complex op2) {//definition l de methode de division
r = op1.r/op2.r;
i = op1.i/op2.i;
}
void Complex::prod (Complex op1, Complex op2) {//definition  de methode de produit
r = op1.r*op2.r;
i = op1.i*op2.i;
}
void Complex::print () {   //l'appel de methode de l'affichage
cout << r <<"+i"<< i;
}
int main () {
Complex operand1, operand2, result;//declaration de coplexe dans main
cout << "entrer la valeur de partie reelle  one: " << endl;
cin >> operand1.r;                 //lecture de variable donner par l'utilisateur de partie reelle de complexe 1
cout << "entrer la valeur de partie imaginaire one: " << endl;
cin >> operand1.i;     //lecture de variable donner par l'utilisateur de partie imaginaire de complexe 1
cout << "entrer la valeur de partie reelle two: " << endl;
cin >> operand2.r;     //lecture de variable donner par l'utilisateur de partie reelle de complexe 2
cout << "entrer la valeur de partie imaginaire two: " << endl;
cin >> operand2.i;    //lecture de variable donner par l'utilisateur de partie imaginaire de complexe 2
result.add(operand1, operand2);//lapelle de methode addition
cout << "la somme est : ";
result.print();   //l'affichage
cout << endl;
result.subtract(operand1, operand2);//lapelle de methode soustraction
cout << "la differance est :";
result.print(); //l'affichage
cout << endl;
result.div(operand1, operand2);//lapelle de methode division
cout << "la division est : ";
result.print(); //l'affichage
cout << endl;
result.prod(operand1, operand2);//lapelle de methode produit
cout << "le produit est : ";
result.print(); //l'affichage
cout << endl;
};
*/
/*
//exercice 2
#include <iostream>
#include<math.h>
class Shape   //classe shape
{
protected:
  float x, y;
public:
  Shape(float _x, float _y)//constructeur parametree
  {
    x = _x;
    y = _y;
  }
};
class Rectangle: public Shape//sous classe rectangle
{
public:
  Rectangle(float _x, float _y) : Shape(_x, _y) {}
  float area() //appele de la fonction area()
  {
    return (x * y);
 }
};
class Triangle: public Shape //sous classe triangle
{
public:
  Triangle(float _x, float _y) : Shape(_x, _y) {}
  float area()  // appele de la fonction area()
  {
    return (x * y / 2);
  }
};
int main (){
  Rectangle rectangle(2,3);//teste de la sous classe
  Triangle triangle(2,3);  //teste de la sous classe
  cout << rectangle.area() << endl;   //6
  cout << triangle.area() << endl;    //3
  return 0;
}
*//*
//programme 4
#include <iostream>
#include<math.h>
class mere{ // Cr�ation de la classe Mere
public:
  void display ()  // Methode display()
  {
    cout << "La m�thode display de la classe mere est ex�cut�e\n";
  }
};
class Fille : public mere{ // Cr�ation du sous-classe Fille
public:
  void display ()
  {
    cout << "La m�thode display de la classe B est ex�cut�e\n";
  }
};
int main ()
{
  Fille fille;
  fille.display();
  return 0;
}
*/
//programme 5:

/*
using namespace std;

class Animal{// Cr�ation de la classe Animal
    protected:// Les attributs
    string nom;
    int age;
    public:// La m�thode set_value
    void set_value(string nom, int age){
        this->nom = nom; //declaration
        this->age = age;
    }
};
// Cr�ation de la  sous-classe Zebra
class Zebra: public Animal{
    private:
    string lieu;
    public:
    void set_value(string nom, int age, string lieu){
        this->lieu = lieu;
        this->nom = nom;
        this->age = age;

    }
    // La m�thode print()
    void print(){
        cout<<nom<<" "<<age<<" d'origine "<<lieu<<endl;
    }
};
// Cr�ation du sous-classe Dolphin
class Dolphin: public Animal{
    private:
    string lieu;
    public:
    void set_value(string nom, int age, string lieu){
        this->lieu = lieu;
        this->nom = nom;
        this->age = age;
    }
    // La m�thode print()
    void print(){
        cout<<nom<<" "<<age<<" d'origine "<<lieu<<endl;
    }};
int main(){
    // Cr�ation des instances zebra et dolphin
    Zebra zebra;
    Dolphin dolphin;
    dolphin.set_value("dolphin",9 , "Australia");
    dolphin.print();
    zebra.set_value("zebra", 20, "Africa");
    zebra.print();
    return 0;
}*/

//programme 7:

/*
class vecteur3d {//classe vecteur 3d
	float x; //declaration
	float y;
	float z;
	public:
	//Constructeur d'initialisation
	vecteur3d(float a = 0, float b = 0, float c = 0) : x(a), y(b), z(c) {
	}
	//Constructeur de recopie
	vecteur3d(const vecteur3d & v) {
		x = v.x;
		y = v.y;
		z = v.z;
	}
	//L'affichage d'un vecteur
	void afficher() {
		cout << "("<<x<<","<<y<<","<<z<<")" << endl;
	}
	//La somme de deux vecteur
	vecteur3d somme(const vecteur3d & v) {
		vecteur3d s;
		s.x = x + v.x;
		s.y = y + v.y;
		s.z = z + v.z;
		return s;
		//Ou return vecteur3d(x+v.x, y+v.y, z+v.z);
	}
	//Le produit scalaire de deux vecteurs
	float produit(const vecteur3d & v) {
		return x*v.x + y*v.y + z*v.z;
	}
//tester si deux vecteurs ont les memes composantes
	bool coincide(const vecteur3d & v) {
		return (x == v.x && y == v.y && z == v.z);
	}
	//Retourner la norme du vecteur
	float norme() {
		return sqrt(x*x + y*y + z*z);
	}
	//Retourner le vecteur qui la plus grande norme : par valeur
	vecteur3d normax(vecteur3d v) {
		if( this->norme() > v.norme())
		    return *this;
		return v;
	}
	//Retourner le vecteur qui la plus grande norme : par adresse
	vecteur3d * normax(vecteur3d * v) {
		if( this->norme() > v->norme())
		    return this;

		return v;
	}
	//Retourner le vecteur qui la plus grande norme : par reference
	vecteur3d & normaxR(vecteur3d &v) {
		if( this->norme() > v.norme())
		    return *this;
		return v;}};
int main() {
	vecteur3d v1(1,2,3);
	cout << "Vecteur V1";
	v1.afficher();
	vecteur3d v2(5,6,7);
	cout << "Vecteur V2";
	v2.afficher();
	cout<<endl;
	cout << "La somme des vecteurs v1 et v2 est : ";
	(v1.somme(v2)).afficher();
	cout << "Le produit scalaire des vecteurs v1 et v2 est : " << v1.produit(v2) << endl;
	cout<<endl;
	cout << "Copier le vecteur V1 dans V3:" << endl;
	vecteur3d v3(v1);
	cout << "Vecteur V3";
	v3.afficher();
	if(v1.coincide(v3))
	    cout << "Les vecteurs v1 et v3 coincident " << endl;
	else
	    cout << "Les vecteurs v1 et v3 ne coincident pas " << endl;
    cout<<endl;
	cout << "Le vecteur qui a la plus grande norme est (par valeur): ";
	(v1.normax(v2)).afficher();
	cout << "Le vecteur qui a la plus grande norme est (par adresse): ";
	(v1.normax(&v2))->afficher();
	cout << "Le vecteur qui a la plus grande norme est (par reference) :";
	(v1.normaxR(v2)).afficher();
	cout<<endl;
}*/
/*
//Programme 6 :

using namespace std;
// Cr�ation de la classe Personne
class Personne{
    // Les attributs
    protected:
    string nom;
    string prenom;
    string date_naissace;
    // Le constructeur
    public:
    Personne(string nom, string prenom, string date_naissace){
        this->nom = nom;
        this->prenom = prenom;
        this->date_naissace = date_naissace;
    }
    // La m�thode afficher()
    void afficher(){
        cout<<nom<<" "<<prenom<<"n�e en "<<date_naissace<<endl;
    }
};
// Sous-classe de Personne
class Employee: public Personne{
    // Les attributs
    protected:
    float salaire;
    // Le constructeur
    public:
    Employee(string nom, string prenom, string date_naissace, float salaire):Personne(nom, prenom, date_naissace){
        this->salaire = salaire;
    }
    // La m�thode afficher()
    void afficher(){
        cout<<nom<<" "<<prenom<<" n�e en "<<date_naissace<<" qui a un salaire de :"<<salaire<<"DH."<<endl;
    }
};
// Sous-classe de Employee
class Chef: public Employee{
    // Les attributs
    protected:
    string service;
    // Le constructeur
    public:
    Chef(string nom, string prenom, string date_naissace, float salaire, string service):Employee(nom, prenom, date_naissace, salaire){
        this->service = service;
    }
    // La m�thode afficher()
    void afficher(){
        cout<<nom<<" "<<prenom<<" n�e en "<<date_naissace<<" qui a un salaire de :"<<salaire<<"DH, en service "<<service<<endl;
    }
};
// Sous-classe de Chef
class Directeur: public Chef{
    // Les m�thodes
    protected:
    string societe;
    // Le constructeur
    public:
    Directeur(string nom, string prenom, string date_naissace, float salaire, string service, string societe):Chef(nom, prenom,date_naissace, salaire, service){
        this->societe = societe;
    }
    // La m�thode afficher()
    void afficher(){
        cout<<nom<<" "<<prenom<<" n�e en "<<date_naissace<<" qui a un salaire de :"<<salaire<<"DH, en service "<<service<<" � "<<societe<<endl;
    }
};

int main(){
    // Cr�ation des instances
    Employee emp("gnoni", "aya", "13_01_2001", 20000);
    emp.afficher();
    Chef chef("qbibche", "najlae", "13_01_2001", 25000, "google scholar");
    chef.afficher();
    Directeur direc("karim", "othmane", "13_01_2000", 300000, "google scholar", "google");
    direc.afficher();

    return 0;
};

*/
/*
//programme 8
#include <iostream>
#include<math.h>
using namespace std;
// Cr�ation de la classe Media
class Media{
    // Les attributs
    protected:
    string titre;
    // Fonctions membres virtuelles
    public:
    virtual void set(string titre){
        this->titre = titre;
    }
    virtual void imprimer() = 0;

};
// Sous-classe Media Livre
class Livre: public Media{
    // Les attributs
    private:
    string auteur;
    string date;
    // Les m�thodes
    public:
    void set(string titre, string auteur, string date){
        this->titre = titre;
        this->auteur = auteur;
        this->date = date;
    }
    void imprimer(){
        cout<<"Ce livre est imprim�"<<endl;
    }

};
// Sous-classe Media Audio
class Audio: public Media{
    // M�thode virtuelle
    public:
    virtual void set(string titre){
        this->titre = titre;
    }
    // Les m�thodes
    void imprimer(){
        cout<<"Ce m�dia est non imprim�"<<endl;
    }
    virtual void playing(){
        cout<<"audio "<<titre<<" is playing"<<endl;
    }

};
// Sous-classe Audio CD
class CD: public Audio{
    public:
    void playing(){
        cout<<"CD is playing"<<endl;
    }

};
// Sous-classe Audio Cassette
class Cassette: public Audio{
    public:
    void playing(){
        cout<<"Cassette is playing"<<endl;
    }

};
// Sous-classe Audio Disque
class Disque: public Audio{
    public:
    void playing(){
        cout<<"Disque is playing"<<endl;
    }
};
// Sous-classe Media Presse
class Presse: public Media{
    // Les attributs
    protected:
    string date;
    // M�thodes virtuelles
    public:
    virtual void set(string titre, string date){
        this->titre = titre;
        this->date = date;
    }
    virtual void afficher() = 0;
    // M�thode imprimer()
    void imprimer(){
        cout<<"ce type de media est imprim�"<<endl;
    }
};
// Sous-classe Magazine
class Magazine: public Presse{
    public:
    void set(string titre, string date){
        this->titre = titre;
        this->date = date;
    }
    void afficher(){
        cout<<"La magazine "<<titre<<" a �t� publi� le "<<date<<endl;
    }
};
// Sous-classe Journal
class Journal: public Presse{
    public:
    void set(string titre, string date){
        this->titre = titre;
        this->date = date;
    }
    void afficher(){
        cout<<"Le journal "<<titre<<" a �t� publi� le "<<date<<endl;
    }
};
// Sous-classe Revue
class Revue: public Presse{
    public:
    void set(string titre, string date){
        this->titre = titre;
        this->date = date;
    }
    void afficher(){
        cout<<"La revue "<<titre<<" a �t� publi� le "<<date<<endl;
    }};
int main(){
    // Cr�ation des instances
    Media *media;
    Livre livre;
    media = &livre;
    livre.set("Livre 1", "Paolo", "12/07/2015");
    media->imprimer();
    Audio *audio;
    Disque disque;
    audio = &disque;
    audio->playing();
    audio->imprimer();
    Presse *presse;
    Journal journal;
    presse = &journal;
    presse->imprimer();
    presse->set("Le matin", "9 decembre");
    presse->afficher();
    return 0;}
    */
//programme 9:
/*
#include <iostream>
using namespace std;
// Cr�ation de la classe Test
class Test{
    // Attribut statique
    public:
    static int count;
    // M�thode call()
    void call(){
        count++;
        cout<<count<<endl;
    }
};
// Initialisation d'attribut count
int Test::count = 0;

int main(){
    // Cr�ation de l'instance test1
    Test test1;
    test1.call();
    test1.call();
    test1.call();
    return 0;
}
*/
